const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');

const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');

module.exports.employeeSearch = async (req) => {
    const logger = new Logger(`Product: EMS | Method: employeeRegistration`);

    try {
        logger.info(`Entering ${BUSINESS_LOGIC_METHOD} | METHOD: employeeManage | ${JSON.stringify(req)}`);

        const condition = {
            registration_number: req.registration_number
        };

        // Query the database using the registration_number
        let employeeData = await employeeManageService.getEmployeeData(condition, ['registration_number', 'first_name', 'middle_name', 'last_name', 'mobile_number', 'address_1', 'address_2', 'city', 'pincode', 'education', 'skills', 'experience', 'email', 'registration_number'], logger);
        logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

        // If employeeData exists and registration_number matches
        if (employeeData && employeeData.registration_number === req.registration_number) {
            return {
                status: STATUS_CODE.SUCCESS,
                data: employeeData,
                message: 'Employee Data Fetched Successfully'
            };
        }

        // If no matching data is found
        return {
            status: STATUS_CODE.NOT_FOUND,
            message: 'Employee Details Not Found'
        };

    } catch (error) {
        // Catch and log any errors
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EMS_SEARCH_API_FAILED,
        };
    }
};
