// const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
// const { BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');

// const employeeManageService = require('../services/employeeManageService');
// const Logger = require('../../utils/logger');
// const { errorFormat } = require('../../utils/errorFormat');

// module.exports.getUserDetail = async (req) => {
//     const logger = new Logger(`Product: EMS | Method: employeeRegistration`);

//     try {
//         logger.info(`Entering ${BUSINESS_LOGIC_METHOD} | METHOD: employeeManage | ${JSON.stringify(req)}`);

//         const condition = {
//             registration_number: req.registration_number
//         };

//         // Query the database using the registration_number
//         let userData = await employeeManageService.getuserData(condition, ['registration_number', 'first_name', 'middle_name', 'last_name', 'mobile_number', 'address_1', 'address_2', 'city', 'pincode', 'education', 'skills', 'experience', 'email', 'registration_number'], logger);
//         logger.info(`userData | ${JSON.stringify(userData)}`);

//         // If userData exists and registration_number matches
//         if (userData && userData.registration_number === req.registration_number) {
//             return {
//                 status: STATUS_CODE.SUCCESS,
//                 data: userData,
//                 message: 'Employee Data Fetched Successfully'
//             };
//         }

//         // If no matching data is found
//         return {
//             status: STATUS_CODE.NOT_FOUND,
//             message: 'Employee Details Not Found'
//         };

//     } catch (error) {
//         // Catch and log any errors
//         logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
//         return {
//             status: STATUS_CODE.INTERNAL_ERROR,
//             message: "Internal Error",
//             error: ERR_MESSAGE.EMS_SEARCH_API_FAILED,
//         };
//     }
// };

const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');

const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const moment = require('moment');

module.exports.getUserDetail = async (req) => {
    const logger = new Logger(`Product: DMS | Method: getUserDetails`);

    try {
        logger.info(`Entering ${BUSINESS_LOGIC_METHOD} | METHOD: getUserDetails | ${JSON.stringify(req)}`);
        let requestDate = moment(req.request_date, 'M/D/YYYY').format('YYYY-MM-DD');
        let updateData


        const condition = {
            request_id: req.requestId,
        };


        let userData = await employeeManageService.getDeviceData(condition, ['request_id', 'name'], logger);
        logger.info(`userData: ${JSON.stringify(userData)}`);

        if (userData && userData.length > 0) {

             updateData = {
                request_date: requestDate
            };

            let userData1 = await employeeManageService.updateDeviceService(condition, updateData);
            logger.info(`userData1: ${JSON.stringify(userData1)}`);
        
            if (!userData1) {
                logger.error('userData1 is null or undefined');
            }
        }
            return {
                status: STATUS_CODE.SUCCESS,
                data: userData,
                message: 'User Data Updated Successfully',
            };
        


    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.DMS_SEARCH_API_FAILED,
        };
    }
};
