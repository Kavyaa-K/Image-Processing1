// const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE, UNAUTHORIZED } = require('../../constants/constant');
// const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
// const employeeManageService = require('../services/employeeManageService');
// const Logger = require('../../utils/logger');
// const { errorFormat } = require('../../utils/errorFormat');

// module.exports.registrationUser = async (req) => {
//     const logger = new Logger(`Product: EMS | Method: registrationUser`);

//     try {
//         logger.info(` ${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_LOGIN} | request |  ${JSON.stringify(req)}`);

//         const payload = { ...req };

//         let employeeData = await employeeManageService.RegisterUser(payload, logger);
//         logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

//         return {
//             status: STATUS_CODE.SUCCESS,
//             message: 'User Registration Successfully'
//         };
//     } catch (error) {
//         logger.error(`${ERROR_CODE.API_INTERNAL} | userLogin | error | ${errorFormat(error)}`);
//         return {
//             status: STATUS_CODE.INTERNAL_ERROR,
//             message: "Internal Error",
//             error: ERR_MESSAGE.USER_LOGIN_API_FAILED,
//         };
//     }
// };


const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');

module.exports.employeeManage = async (req) => {
    const logger = new Logger(`Product: EMS | Method: registrationUser`);

    try {
        logger.info(`${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_LOGIN} | request | ${JSON.stringify(req)}`);

        const payload = { ...req };

        // Check if the user already exists
        let existingUser = await employeeManageService.findEmployeeByEmail(payload.email, logger);
        logger.info(`existingUser ${JSON.stringify(existingUser)}`);

        if (existingUser) {
            logger.info(`User already registered with email: ${payload.email}`);
            return {
                status: STATUS_CODE.SUCCESS,
                message: 'User already registered',
                // user: existingUser
            };
        } else {
            logger.info(`No user found with email: ${payload.email}`);
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: 'No user found'
            };
        }
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | registrationUser | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.USER_LOGIN_API_FAILED,
        };
    }
};
