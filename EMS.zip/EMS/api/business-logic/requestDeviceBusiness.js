const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');
const { v4: uuidv4 } = require('uuid');  // Import UUID library for generating unique IDs

module.exports.requestDevice = async (req) => {
    const logger = new Logger(`Product : DMS | Method : requestDevice`);

    try {
        logger.info(` ${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} | METHOD : requestDevice | ${JSON.stringify(req)}`);

        // Generate a unique requestId (UUID)
        const generateRequestId = () => {
        return 'REQ' + uuidv4().replace(/\D/g, '').substring(0, 9); 
        };  // This will generate a globally unique requestId
        logger.info(`generateRequestId | ${generateRequestId}`);

        const payload = {
            ...req, // assuming req.body contains the employee data
            request_id: generateRequestId(), // Add the unique requestId here
        };
        console.log(payload);
        
        let deviceData = await employeeManageService.createDeviceService(payload);
        logger.info(`deviceData | ${JSON.stringify(deviceData)}`);

        return {
            status: STATUS_CODE.SUCCESS,
            requestId: payload.request_id, // Return the generated requestId here
            message: 'Success'
        };
        
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EMS_API_FAILED
        };
    }
};
