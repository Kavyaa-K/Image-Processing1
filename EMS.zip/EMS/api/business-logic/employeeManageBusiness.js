const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const { errorFormat } = require('../../utils/errorFormat');

module.exports.employeeManage = async (req) => {
    const logger = new Logger(`Product : EMS | Method : employeeRegistration`);

    try {
        logger.info(` ${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} | METHOD : employeeManage | ${JSON.stringify(req)}`);

        const condition = {
            mobile_number: req.mobile_number
        }

        let mobileData = await employeeManageService.getMobileData(condition, ['mobile_number'], logger);
        logger.info(`mobileData | ${JSON.stringify(mobileData)}`);

        if (mobileData && mobileData.mobile_number === req?.mobile_number) {          // Mobile number already exists
            return {                                                                // You can return an error response here
                status: STATUS_CODE.BAD_REQUEST,
                message: 'Mobile number already exists'
            }
        }

        else {
            let reportData = await employeeManageService.getRegistrationNumber(['registration_number'], logger);
            logger.info(`reportData | ${JSON.stringify(reportData)}`);

            let currentNumber = reportData?.registration_number ?? 2025000;
            function registrationNumber() {
                return ++currentNumber;
            }
            let registration_number = registrationNumber();
            logger.info(`registration_number | ${JSON.stringify(registration_number)}`);

            const payload = {
                ...req,                                                                 // assuming req.body contains the employee data
                registration_number: registration_number,                               // Add the registration number here
            };

            let employeeData = await employeeManageService.createEmployeeService(payload);
            logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

            return {
                status: STATUS_CODE.SUCCESS,
                registrationNumber: registration_number,
                message: 'Success'
            }
        }
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage |  error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EMS_API_FAILED
        }
    }
};