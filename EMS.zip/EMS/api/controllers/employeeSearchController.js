const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD,METHOD } = require('../../constants/constantLogger');
const employeeSearchBusiness = require('../business-logic/employeeSearchBusiness');
const logger = new Logger(`Product : EMS | Method : EMS_DETAILS `);
logger.info('EMS Enter')

const employeeSearch = async (req, res) => {

    const logger = new Logger('Employee Details');
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.EMPLOYEE_SEARCH} | request ${JSON.stringify(req.body)}`);

    await employeeSearchBusiness.employeeSearch
        (req.body).then(response => {
            writeJson(res, response)
        })
}
module.exports = { employeeSearch }

