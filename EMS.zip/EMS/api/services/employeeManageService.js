const device = require('../../models/device');
const employee = require('../../models/employee'); 

async function createEmployeeService(payload) {
    try {
        let employeeAddition = await employee.create(payload)
        // console.log(employeeAddition);
        return employeeAddition
    } catch (error) {
        // logger.error(`createEmployeeService | error | ${error}`);
    }
};

const getMobileData = (condition, columns, logger) => {
    logger.info(`getMobileData: ${JSON.stringify(condition)}`);    // Log the condition properly
    return employee.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getMobileData | error | ${error}`);
        throw error; // Ensure error is properly handled
    });
};

const getRegistrationNumber = (columns, logger) => {
    logger.info(`getRegistrationNumber ${JSON.stringify(columns)}`);
    return employee.findOne({
        attributes: columns,
        order: [['CreatedTime', 'DESC']],
        raw: true,
    }).catch((error) => {
        logger.error(`getRegistrationNumber | error | ${error}`);
        throw error; // Ensure error is properly handled
    });
};

const getEmployeeData = (condition, columns, logger) => {
    logger.info(`getEmployeeData: ${JSON.stringify(condition)}`); // Log the condition properly
    return employee.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getEmployeeData | error | ${error}`);
        throw error; // Ensure error is properly handled
    });
};

// async function createDeviceService(payload) {
//     try {
//         let deviceAddition = await device.create(payload)
//         // console.log(employeeAddition);
//         return deviceAddition
//     } catch (error) {
//         // logger.error(`createEmployeeService | error | ${error}`);
//     }
// };

const createDeviceService = (payload) => {
    // logger.info(`createDeviceService: ${JSON.stringify(payload)}`); // Log the payload properly

    return device.create(payload) 
        .then((newRequest) => {
            return newRequest; 
        })
        .catch((error) => {
            throw error; 
        });
};

const getDeviceData = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`); 
    return device.findOne({
        attributes: columns, 
        where: condition,    
        raw: true,          
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`); 
        throw error; 
    });
};

// const updateDeviceService = (updateData, condition) => {
//     // logger.info(`updatePerson-ENTERING TO  UPDATE PERSON TABLE | DATA | ${(JSON.stringify(updateData))}`);
//     return device.update(
//       updateData,
//       {
//         where: condition,
//       },
//     ).catch((err) => {
//       throw err;
//     });
//   };

const updateDeviceService = (updateData, condition) => {
    // logger.info(`updateDeviceService | Data: ${JSON.stringify(updateData)} | Condition: ${JSON.stringify(condition)}`);
    
    return device.update(
      updateData,
      { where: condition }
    ).catch((err) => {
    //   logger.error('Error updating device service:', err);
      throw err;
    });
  };



module.exports = {
    createEmployeeService,
    getMobileData,
    getRegistrationNumber,
    getEmployeeData,
    createDeviceService,
    getDeviceData,
    updateDeviceService
}
