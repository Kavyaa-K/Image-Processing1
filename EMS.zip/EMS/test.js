    
// const { v4: uuidv4 } = require('uuid');  // Import UUID library for generating unique IDs
// const requestId = uuidv4();  // This will generate a globally unique requestId
//     console.log(`requestId | ${requestId}`);

// const crypto = require('crypto');
 
// const generateRequestId = () => {
//     return crypto.randomInt(1000000000, 9999999999).toString();
// };
 
// console.log(generateRequestId()); // Example: 8256493120

// const { v4: uuidv4 } = require('uuid');
 
// const generateRequestId = () => {
//     return uuidv4().replace(/\D/g, '').substring(0, 10);
// };
 
// console.log(generateRequestId());

const { v4: uuidv4 } = require('uuid');
 
const generateRequestId = () => {
    return 'REQ' + uuidv4().replace(/\D/g, '').substring(0, 9); 
};
 
console.log(generateRequestId());