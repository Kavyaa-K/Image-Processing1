const dbConfig = require("../config/dbConfig"); //  Sequelize instance
const Logger = require("../utils/logger"); //  Import Logger

const logger = new Logger(); //  Initialize Logger

dbConfig.authenticate()
  .then(() => {
    logger.info("Connection has been established successfully.");
  })
  .catch((error) => {
    logger.error("Error occured while connecting to database ...!", error);
  });
