const dbconfig = require('../config/dbConfig')
const Sequelize = require('sequelize')

var device = dbconfig.define('device', {

    id: {
        type: Sequelize.INTEGER,
        // allowNull: false
        primaryKey: true
    },
    name: Sequelize.STRING,   //connecting mysql with node js server
    desk: Sequelize.STRING,
    floor: Sequelize.STRING,
    tower: Sequelize.STRING,
    email: Sequelize.STRING,
    request_id: Sequelize.STRING,
    device_name: Sequelize.STRING,
    request_date: Sequelize.DATE,
    createdTime: Sequelize.DATE,
    updatedTime: Sequelize.DATE,
},
    {
        updatedAt: 'updatedTime',
        createdAt: 'createdTime',
        freezeTableName: true,
    });

module.exports = device
