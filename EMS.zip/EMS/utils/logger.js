const bunyan = require("bunyan");
const properties = require("../package.json");
const env = process.env.NODE_ENV;
const bformat = require("bunyan-format");
const moment = require("moment-timezone");

function getISTTime() {
    return moment().tz("Asia/Kolkata").format("YYYY-MM-DD HH:mm:ss");
}

const formatOut = bformat({
    outputMode: "long",
    color: true,
    stream: process.stdout,
});

const envCondition = ["production", "pre_prod"].includes(env);

// Logs Condition
const streamConditions = envCondition
    ? [{ stream: process.stdout, level: "info" }]
    : [{ stream: formatOut, level: "debug" }];

const logger = bunyan.createLogger({
    name: "ems-logging <EMS>",
    streams: streamConditions,
});

class Logger {
    constructor(fnName, trace) {
        this.updateInfo(fnName, trace);
    }

    updateInfo(fnName, trace) {
        this.fnName = fnName;
        this.trace = trace;
        if (fnName || trace) {
            this.info('BEGIN');
        }
    }

    formatMessage(level, msg) {
        const timestamp = getISTTime();
        let logMsg = `[${timestamp}] Micro : ${properties.name} |`;

        if (this.fnName) logMsg += ` Method: ${this.fnName} |`;
        if (this.trace) lolevelgMsg += ` Trace: ${this.trace} |`;

        return `${logMsg} ${msg}`;
    }

    info(...msg) {
        msg[0] = this.formatMessage("INFO", msg[0]);
        logger.info(...msg);
    }

    debug(...msg) {
        msg[0] = this.formatMessage("DEBUG", msg[0]);
        logger.debug(...msg);
    }

    error(...msg) {
        msg[0] = this.formatMessage("ERROR", msg[0]);
        logger.error(...msg);
    }
}

module.exports = Logger;