
const Sequelize = require('sequelize'); //  Import Sequelize
const { config } = require('./environConfig'); //  Import the environment config
const Logger = require('../utils/logger');


const logger = new Logger(); //  Initialize logger

//  Sequelize connection
const sequelize = new Sequelize(config.database, config.username, config.password, {
    host: config.host,
    dialect: 'mysql',
    dialectOptions: {
        multipleStatements: true,
    },
    useUtc: false,
    timezone: '+05:30',

    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000,
    },
    logging: (msg) => logger.info(`Sequelize: ${msg}`), //  Logs SQL queries
});

module.exports = sequelize; //  Export Sequelize instance
