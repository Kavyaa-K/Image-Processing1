// const environConfig = {
//     local: {
//         dbHost: "localhost",
//         dbUserName: "sharath",
//         dbPassword: 'password'
//     },
//     development: {

//     }
// };

// const environment = process.env.NODE_ENV || 'local';
// const config = environConfig['local'];
// console.log(environConfig[environment], environment);

// module.exports = config;


// const Logger = require('../utils/logger'); // Import the Logger
// const logger = new Logger(); // Initialize Logger

// const env = process.env.NODE_ENV || 'development'; // Default to 'development'

// logger.info(`Using environment: ${env}`)


// const environConfig = {
//     development: {
//         database: 'ems', // ✅ Database Name
//         username: 'sharath', // ✅ DB Username
//         password: 'password', // ✅ DB Password
//         host: 'localhost', // ✅ Localhost
//         // port: '3306', // ✅ MySQL Default Port
//         // dialect: 'mysql', // ✅ Specifies MySQL as the DB

//     },

//     qa: {
//         database: 'ems', // ✅ Database Name
//         username: 'sharath', // ✅ DB Username
//         password: 'password', // ✅ DB Password
//         host: 'localhost', // ✅ Localhost
//         // port: '3306', // ✅ MySQL Default Port
//         // dialect: 'mysql', // ✅ Specifies MySQL as the DB

//     },
// };
// module.exports = { environConfig, env };







require('dotenv').config(); // Load environment variables

const Logger = require('../utils/logger'); // Import the Logger
const logger = new Logger(); // Initialize Logger

const env = process.env.NODE_ENV || 'development'; // Set environment

logger.info(`Using environment: ${env}`); // Log the environment

const environConfig = {
    development: {
        database: process.env.DB_NAME || 'ems',
        username: process.env.DB_USER || 'Kavya',
        password: process.env.DB_PASS || 'password',
        host: process.env.DB_HOST || 'localhost',
    },
    qa: {
        database: process.env.DB_NAME || 'ems',
        username: process.env.DB_USER || 'root',
        password: process.env.DB_PASS || 'password',
        host: process.env.DB_HOST || 'localhost',
    },
};

module.exports = { config: environConfig[env], env };
